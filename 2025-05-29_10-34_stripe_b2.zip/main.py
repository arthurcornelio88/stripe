def main():
    print("Hello from stripe!")


if __name__ == "__main__":
    main()
