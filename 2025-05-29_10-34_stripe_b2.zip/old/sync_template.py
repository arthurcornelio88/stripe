import stripe
from app.db.session import SessionLocal
from app.models.{table} import {ClassName}
from app.transformers.{table} import stripe_{table}_to_model
from sqlalchemy.orm import Session
import os
from dotenv import load_dotenv

load_dotenv()
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

def sync_{table}():
    db: Session = SessionLocal()
    existing_ids = {x.id for x in db.query({ClassName}.id).all()}

    count = 0
    for obj in stripe.{ClassName}.list(limit=100).auto_paging_iter():
        if obj["id"] not in existing_ids:
            model = stripe_{table}_to_model(obj)
            db.add(model)
            print(f"➕ Added {table}: {model.id}")
            count += 1
        else:
            print(f"✅ Skipped existing {table}: {obj['id']}")

    db.commit()
    db.close()
    print(f"✅ Synced {count} new {table}s")

if __name__ == "__main__":
    sync_{table}()
