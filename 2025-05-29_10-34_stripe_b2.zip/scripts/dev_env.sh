#!/bin/bash
export PYTHONPATH="$(pwd)"
echo "✅ PYTHONPATH set to $(pwd)"
