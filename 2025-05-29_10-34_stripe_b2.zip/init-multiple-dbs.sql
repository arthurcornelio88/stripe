-- init-multiple-dbs.sql
CREATE DATABASE stripe_db;
CREATE DATABASE stripe_test;

